
Unter Verwendung der Bibliothek 'AsOpcUac' ist hier das Beispiel eines Clients implementiert.

Allgemeine Konfiguration:
	In der lokalen Struktur 'ClientCfg' sind einige Parameter f�r die Verbindung und die restlichen Funktionalit�ten
	enthalten.	Alle hier nicht enthaltenen Parameter sind im Code statisch gesetzt.
	Die Bedeutung der Parameter und ihre Verwendung k�nnen in der AS-Hilfe nachgelesen werden.

Funktionalit�t:
	Der Client baut automatisch nach dem Hochlauf der Sps die Verbindung zum Server auf. Die Variable 'bStartClient'
	ist im Init auf '1' gesetzt. Will man den Client nicht automatisch starten, kann diese Variable im Init auf '0' und
	dann im Watch auf '1' gesetzt werden.
	Verbunden wird auf den eigenen Server. Durch �nderung der Parameter kann aber auch auf einen externen Server verbunden
	werden.
	
	Der Ablauf sieht wie folgt aus:
		1. Aufbauen der Verbindung
		2. Anlegen einer Subscription
		3. Ermitteln der NodeHandles f�r die Subscription
		4. Hinzuf�gen eines MonitoredItems
		5. Schleife auf 4. Wenn alle MonitoredItems angelegt sind, wird auf Punkt 6. gesprungen
		6. Schleife auf 2. Wenn alle Subscriptions angelegt sind, wird auf Punkt 7. gesprungen
		7. Ermitteln der NodeHandles f�r Read
		8. Ermitteln der NodeHandles f�r Write
		9. Verbindungs-Abbruch pr�fen
		10. Alle 1000ms wird zu 12 gesprungen
		11. Lesen der Read-Werte
		12. Schreiben der Write-Werte
		13. Sprung auf 10.

	Subscription:
		Es werden 3 Subscriptions mit je 4 MonitoredItems angelegt. Die Parameter der Subscriptions sind wie folgt vergeben:
		Sub[0]:		PublishingInterval: 500ms					Priority: 200
		Sub[1]:		PublishingInterval: 1000ms				Priority: 100
		Sub[2]:		PublishingInterval: 2000ms				Priority: 50
	
		Da in AS4.1 der FB 'UA_MonitoredItemAddList' noch nicht verf�gbar ist (erst ab AS4.2), werden die MonitoredItems
		hier noch mit 'UA_MonitoredItemAdd'	hinzugef�gt. Dazu werden die Schritte f�r jedes Item durchlaufen.
		Abonniert werden alle Standard-Datentypen der Struktur 'ServerData::VarsLocal.ReadOnly'. Das INT-Array	wird nicht
		abonniert. Die empfangenen Werte werden in die lokale Struktur 'ClientXXX:ClientVarsSubscription' eingetragen.

	Read:
		Alle 1000ms werden Werte gelesen.
		Gelesen werden von der Struktur 'ServerData:VarsLocal.ReadOnly' jeweils die Elemente 'nUdint', 'nDint' und
		'anInt' (Array) und in die entsprechenden Elemente der lokalen Struktur 'ClientXXX:ClientVarsRead' eingetragen.
		
	Write:
		Alle 1000ms werden Werte geschrieben.
		Geschrieben werden die oben gelesenen Elemente von der lokalen Struktur 'ClientXXX:ClientVarsRead' auf 
		'ServerData::WriteXXX'.
	
	NamespaceUri und NamespaceIndex:
		Normalerweise w�rde die NamespaceUri verwendet, um einen Knoten zu adressieren. Da aber die �bertragung eines
		Texts bei jedem Zugriff zu unperfomant w�re, wird bei OpcUa der NamespaceUri in einen ebenso eindeutigen
		NamespaceIndex gewandelt.
		Achtung: Der NamespaceIndex ist nicht statisch und muss folglich nach jedem Verbingungsaufbau mit
		'UA_GetNamespaceIndex' ermittelt werden!
		Jeder Knoten k�nnte theoretisch in einem anderen Namespace untergebracht sein. Weil beim B&R-Server die Variablen 
		aber alle im selben Namespace sind,	wird hier der Index nur einmal ermittelt und f�r jedes Item verwendet.
		Ab AS4.3 ist die NamespaceUri bei B&R ge�ndert worden:
			AS					Version			NamespaceUri
			<=AS4.2			V1.0				urn:B&R/pv/
			>=As4.3			V2.0				http://br-automation.com/OpcUa/PLC/PV/
		Um kombatibel zu �lteren Versionen zu bleiben, kann ab AS4.3 die Modell-Version in der System-
		Konfiguration eingestellt werden.
		Ursache der �nderung: Manche OpcUa-Client von Fremdherstellern hatten Probleme mit dem '&' im Namespace.

	Verbindungsabbruch:
		Bricht die Verbindung zum Server ab (z.B. durch Abstecken eines Kabels oder Neustart des Servers) und kehrt wieder,
		kann das Betriebssystem automatisch	die Verbindung komplett (mit Subscriptions + MonitoredItems) wieder
		restaurieren. Der Task �berpr�ft lediglich, ob die Verbindung wiedergekehrt ist. 	

	Fehler:
		In der Struktur 'Step' wird der zuletzt aufgetretene Fehler gespeichert sowie der Schritt, in dem der Fehler
		aufgetreten ist, ausserdem optional der	Index der Subscription bzw. des Items.
		Bei manchen Fehlern kann trotzdem weiter gearbeitet werden. Wenn zum Beispiel die Parameter eines MonitoredItems
		falsch sind, k�nnen die restlichen trotzdem angelegt werden.
		Auf den Schritt 'eSTEP_PAR_ERROR' wird nur dann gesprungen, wenn ein Fehler auftritt, bei dem die Schrittkette
		aufgrund eines falschen Parameters nicht weitergf�hrt werden kann. Dieser Parameter muss dann unbedingt berichtigt
		werden, weil sonst der Client nicht arbeitet.
