
Dies ist eine Beispiel-Implementierung f�r einen OpcUa-Client auf einer B&R-Sps �ber die Bibliothek 'AsOpcUac'.
Es ist KEIN offizielles Beispiel und daher besteht f�r den Anwender kein Anspruch auf
Erweiterung, Fehlerbehebung, Schulung oder Support. Auch die Fehlerfreiheit kann nicht
garantiert werden.

Tasks
	Template:		Ist ein Muster, um schneller neue Tasks im selben Format implementieren zu k�nnen.
							Es wird f�r das Beispiel nicht ben�tigt.
	ServerData: Stellt Variablen zur Verf�gung, die am eigenen Server ver�ffentlicht werden und Variablen, welche
							von den Clients beschrieben werden.
	ClientC:		Die Implementierung des Clients in der Sprache ANSI-C.
	ClientST:		Die Implementierung des Clients in der Sprache StructuredText.

In jedem Task ist ebenfalls eine ReadMe.txt enthalten, die ihn n�her beschreibt.

Um dieses Beispiel zu verstehen, ist es zwingend notwendig, die AS-Hilfe zu studieren. Ausserdem sollte sich der
Anwender �ber Konzepte und die allgemeine Funktionsweise von OpcUa informieren. B&R bietet hierf�r auch Kurse an.

Ab AS4.4 k�nnte als Ersatz der OpcUa_Any-Client verwendet werden, welcher im HW-Baum eingef�gt wird und nur
parametriert statt	programmiert werden muss.