
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "Util.h"
#ifdef __cplusplus
	};
#endif

/* Erzeugt eine Zufallszahl zwischen nMin und nMax */
signed long GetRandomDint(signed long nMin, signed long nMax)
{
	DINT nRandom = 0;
	if(nMin == -2147483648UL || nMax == 2147483647)
	{
		nRandom = (DINT)(GetRandomPercent()*nMax);
		BOOL bMinus = GetRandomBool();
		if(bMinus == 1)
		{
			nRandom = nRandom * -1;
		}
	}
	else
	{
		nRandom = (DINT)(GetRandomPercent()*(nMax-nMin+1))+nMin;
	}
	return nRandom;
}
