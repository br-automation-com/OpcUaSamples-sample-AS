
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "Util.h"
#ifdef __cplusplus
	};
#endif
/* Konvertiert einen USINT-Wert in einen Hex-String */
unsigned short ConvertUsintToHexString(unsigned char nValue, plcstring* pHexString, unsigned long nHexStringSize)
{
	brsmemset((UDINT)pHexString, 0, nHexStringSize);
	DINT nDigit = 0;
	for(nDigit=1; nDigit>=0; nDigit--)
	{
		UDINT nHelp1 = 0xF << nDigit * 4;
		UDINT nHelp2 = nValue & nHelp1;
		UDINT nHelp3 = nHelp2 >> nDigit * 4;
		
		if(nHelp3 <= 9)
		{
			STRING sChar[2];
			sChar[0] = 48 + nHelp3;
			sChar[1] = 0;
			brsstrcat((UDINT)pHexString, (UDINT)&sChar);
		}
		else
		{
			STRING sChar[2];
			sChar[0] = 65 + nHelp3 - 10;
			sChar[1] = 0;
			brsstrcat((UDINT)pHexString, (UDINT)&sChar);
		}
	}
	return 0;
}
