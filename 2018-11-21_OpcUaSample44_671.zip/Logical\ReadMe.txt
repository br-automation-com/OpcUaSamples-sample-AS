
Dies ist eine Beispiel-Implementierung f�r einen OpcUa-Client auf einer B&R-Sps �ber die Bibliothek 'AsOpcUac'.
Es ist KEIN offizielles Beispiel und daher besteht f�r den Anwender kein Anspruch auf
Erweiterung, Fehlerbehebung, Schulung oder Support. Auch die Fehlerfreiheit kann nicht
garantiert werden.

Tasks
	Template:		Ist ein Muster, um schneller neue Tasks im selben Format implementieren zu k�nnen.
							Es wird f�r das Beispiel nicht ben�tigt.
	ServerData: Stellt Variablen zur Verf�gung, die am eigenen Server ver�ffentlicht werden und Variablen, welche
							von den Clients beschrieben werden.
	ClientC:		Die Implementierung des Clients in der Sprache ANSI-C.
	ClientST:		Die Implementierung des Clients in der Sprache StructuredText.

In jedem Task ist ebenfalls eine ReadMe.txt enthalten, die ihn n�her beschreibt.

Um dieses Beispiel zu verstehen, ist es zwingend notwendig, die AS-Hilfe zu studieren. Ausserdem sollte sich der
Anwender �ber Konzepte und die allgemeine Funktionsweise von OpcUa aneignen. B&R bietet hierf�r auch Kurse an.

Ab AS4.4 k�nnte als Ersatz der OpcUa_Any-Client verwendet werden, welcher im HW-Baum eingef�gt wird und nur
parametriert statt programmiert werden muss.
	
WICHTIG:
Wird kein jeweils eigenes Zertifikat f�r Server/Client angelegt, werden beim erstmaligem Starten der SPS
automatisch Zertifikate erzeugt, welche aber nur einen G�ltigkeitszeitraum von 10 Jahren haben. Ist ein Zertifikat
ung�ltig, wird es nicht mehr akzeptiert und es kommt keine Verbindung zustande!
Bei einer realen Anwendung sollten also unbedingt eigene Zertifikate angelegt und verwendet werden.
Siehe dazu AS-Hilfe GUID 'f83f9b82-60fe-4f7c-b101-504cb81ffc44' (='Access & Security/TLS/SSL(SSL bei B&R') sowie
GUID '2c919423-08bb-4895-88b8-afcf6114d0a2' (='Programmierung/Editoren/Konfigurationseditoren/
Hardwarekonfiguration/CPU Konfiguration/SG4/OPC UA Server').
In diesem Beispiel wurde ein Zertifikat unter 'ConfigurationView/AccessAndSecurity/CertificateStore/OwnCertifcates'
mit einer Laufzeit von 99 Jahren angelegt, welches f�r Server und Client verwendet wird.
Dazu wurde die Konfiguration 'ConfigurationView/AccessAndSecurity/TransortLayerSecurity/OpcUa.sslcfg' angelegt,
welche f�r den Server in der System-Konfiguration und f�r den Client am FB 'UA_Connect' angegeben ist.
