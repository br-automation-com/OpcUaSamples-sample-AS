/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2023-04-20 08:30:07Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetNodeId;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetNodeIdNum;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetRandomNodeId;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAreNodeIdsEqual;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddNodeIdText;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSetNodeId),
	new_TestSet(Set_BrbUaSetNodeIdNum),
	new_TestSet(Set_BrbUaGetRandomNodeId),
	new_TestSet(Set_BrbUaAreNodeIdsEqual),
	new_TestSet(Set_BrbUaAddNodeIdText),
};
UNTITTEST_TESTSET_HANDLER();

