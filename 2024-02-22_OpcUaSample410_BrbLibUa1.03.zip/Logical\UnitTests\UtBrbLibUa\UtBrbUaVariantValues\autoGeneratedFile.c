/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2023-04-20 12:30:26Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaClearVariantValue;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaConvVariantValueFromString;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaConvVariantValueToString;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddVariantValueSubName;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaClearVariantValue),
	new_TestSet(Set_BrbUaConvVariantValueFromString),
	new_TestSet(Set_BrbUaConvVariantValueToString),
	new_TestSet(Set_BrbUaAddVariantValueSubName),
};
UNTITTEST_TESTSET_HANDLER();

