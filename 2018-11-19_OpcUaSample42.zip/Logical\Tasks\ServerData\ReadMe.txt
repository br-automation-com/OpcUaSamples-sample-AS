
Hier werden Variablen zur Verf�gung gestellt, die der eigene OpcUa-Server ver�ffentlicht.

Der Server ist in der System-Konfiguration unter 'OPCUA Server' parametriert.

Die User-/Roles-Parametrierung ist unter ConfigurationView/AccessAndSecurity/UserRoleSystem.  Hier ist folgende
Authentifizierung angegeben:
	Username:			Admin
	Password:			admin

Daten sind als globale Variable 'gVarsGlobal' und als lokale Variable 'VarsLocal' angelegt.
Sie wurden in der Datei 'OpcUaMap.uad' (siehe ConfigurationView/Connectivity/OpcUa) f�r den Server konfiguriert.
Sie enthalten die Strukturen 'Read', 'Write' und 'ReadWrite', welche auch so parametriert sind.
Diese wiederum enthalten jeweils ein Unterelement jeden Standard-Datentyps.
Definition siehe LogicalView/Global.typ.
Die Elemente der Unter-Struktur 'Read' werden im Task-Takt (500ms) ge�ndert.

Ausserdem gibt es die Strukturen 'WriteC' und 'WriteST', auf deren Elemente teilweise von den Clients geschrieben wird.
