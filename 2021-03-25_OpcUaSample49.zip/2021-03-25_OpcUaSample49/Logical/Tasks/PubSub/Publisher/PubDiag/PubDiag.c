
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _INIT ProgramInit(void)
{

}

void _CYCLIC ProgramCyclic(void)
{
	// Diagnose-Z�hler der gesendeten Messages
	PublisherDiagData.UdpMessage.nTotal = ArPubSubDGetUdpMsgSendTotal();
	PublisherDiagData.UdpMessage.nError = ArPubSubDGetUdpMsgSendError();
	// Diagnose-Z�hler der gesendeten DataSets
	PublisherDiagData.DataSet.nTotal = ArPubSubDGetDataSetSendTotal();
	PublisherDiagData.DataSet.nError = ArPubSubDGetDataSetSendError();
}

void _EXIT ProgramExit(void)
{

}

