
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _INIT ProgramInit(void)
{
	// Variable verwenden, damit sie zumindest einmal im Code vorkommt und nicht vom Kompiler wegoptimiert wird
	brsmemset((UDINT)&SubscribedData, 0, sizeof(SubscribedData));
}

void _CYCLIC ProgramCyclic(void)
{
	// Dieser Task enth�lt keinen Code, sondern nur die Variablen-Deklaration zur Aufnahme der empfangenen Werte.
}

void _EXIT ProgramExit(void)
{

}

