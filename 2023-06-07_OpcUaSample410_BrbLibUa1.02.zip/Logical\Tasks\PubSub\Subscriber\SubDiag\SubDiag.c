
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*, bugprone-branch-clone)

void _INIT ProgramInit(void)
{

}

void _CYCLIC ProgramCyclic(void)
{
	// Diagnose-Z�hler der empfangenen Messages
	SubscriberDiagData.UdpMessage.nTotal = ArPubSubDGetUdpMsgReceiveTotal();
	SubscriberDiagData.UdpMessage.nError = ArPubSubDGetUdpMsgReceiveError();
	// Diagnose-Z�hler der empfangenen DataSets
	SubscriberDiagData.DataSet.nTotal = ArPubSubDGetDataSetReceiveTotal();
	SubscriberDiagData.DataSet.nError = ArPubSubDGetDataSetReceiveError();
}

void _EXIT ProgramExit(void)
{

}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*, bugprone-branch-clone)
