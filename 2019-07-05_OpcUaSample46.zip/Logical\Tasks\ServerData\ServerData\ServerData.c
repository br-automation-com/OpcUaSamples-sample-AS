#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

// Prototypen der lokalen Funktionen
void IncrementOpcUaTestDatatypes(OpcUaTestDatatypes_TYP* pDatatypes);
void ChangeByteString();
void ChangeByteString20();
void ChangeDynamicStructArray();

void _INIT Init(void)
{
	// Setzen der Test-Variablen
	brsmemset((UDINT)&gVarsGlobal, 0, sizeof(gVarsGlobal));
	brsstrcpy((UDINT)&gVarsGlobal.ReadOnly.sString, (UDINT)&"000");
	
	brsmemset((UDINT)&VarsLocal, 0, sizeof(VarsLocal));
	brsstrcpy((UDINT)&VarsLocal.ReadOnly.sString, (UDINT)&"000");

	brsmemset((UDINT)&WriteC, 0, sizeof(WriteC));
	brsmemset((UDINT)&WriteST, 0, sizeof(WriteST));
	
	ByteStringExample.Length = 1;
	ByteStringExample20.nLength = 1;
	DynamicStructArray.nLength = 1;
	for(nIndex=0;nIndex<=9;nIndex++)
	{
		DynamicStructArray.Data[nIndex].nUsint = (USINT)nIndex;
		DynamicStructArray.Data[nIndex].rReal  = (REAL)nIndex + 0.1;
	}
}

void _CYCLIC Cyclic(void)
{
	IncrementOpcUaTestDatatypes(&gVarsGlobal.ReadOnly);
	IncrementOpcUaTestDatatypes(&VarsLocal.ReadOnly);
	ChangeByteString();
	ChangeByteString20();
	ChangeDynamicStructArray();
}

void _EXIT Exit(void)
{
}

void IncrementOpcUaTestDatatypes(OpcUaTestDatatypes_TYP* pDatatypes)
{
	UINT		nStringLen;
	STRING	sHelpString[nOPCUA_STRING_CHAR_MAX];
	UINT		nHelpStringLen;

	pDatatypes->bBool = !pDatatypes->bBool;
	pDatatypes->nSint++;
	pDatatypes->nInt++;
	pDatatypes->nDint++;
	pDatatypes->nUsint++;
	pDatatypes->nUint++;
	pDatatypes->nUdint++;
	pDatatypes->rReal += 0.1;
	pDatatypes->rLongReal += 0.2;
	pDatatypes->tTime++;
	pDatatypes->dtDateTime++;
	pDatatypes->anInt[0]++;
	pDatatypes->anInt[1]++;
	pDatatypes->anInt[2]++;
	pDatatypes->anInt[3]++;
	pDatatypes->anInt[4]++;

	nStringLen = brsstrlen((UDINT)&pDatatypes->sString);
	brsitoa((DINT)pDatatypes->nUsint, (UDINT)&sHelpString);
	nHelpStringLen = brsstrlen((UDINT)&sHelpString);
	if((nStringLen >= 3))
	{
		if(nHelpStringLen >= 3)
		{
			pDatatypes->sString[0] = sHelpString[0];
			pDatatypes->sString[1] = sHelpString[1];
			pDatatypes->sString[2] = sHelpString[2];
		}
		else if(nHelpStringLen == 2)
		{
			pDatatypes->sString[0] = 48;
			pDatatypes->sString[1] = sHelpString[0];
			pDatatypes->sString[2] = sHelpString[1];
		}
		else
		{
			pDatatypes->sString[0] = 48;
			pDatatypes->sString[1] = 48;
			pDatatypes->sString[2] = sHelpString[0];
		}
	}
	else if((nStringLen == 2))
	{
		if(nHelpStringLen >= 3)
		{
			pDatatypes->sString[0] = sHelpString[1];
			pDatatypes->sString[1] = sHelpString[2];
		}
		else if(nHelpStringLen == 2)
		{
			pDatatypes->sString[0] = sHelpString[0];
			pDatatypes->sString[1] = sHelpString[1];
		}
		else
		{
			pDatatypes->sString[0] = 48;
			pDatatypes->sString[1] = sHelpString[0];
		}
	}
	else if((nStringLen == 1))
	{
		if(nHelpStringLen >= 3)
		{
			pDatatypes->sString[0] = sHelpString[2];
		}
		else if(nHelpStringLen == 2)
		{
			pDatatypes->sString[0] = sHelpString[1];
		}
		else
		{
			pDatatypes->sString[0] = sHelpString[0];
		}
	}
}

void ChangeByteString()
	{
	brsmemset((UDINT)&ByteStringExample, 0, sizeof(ByteStringExample));
	ByteStringExample.Length = GetRandomDint(1, 16);
	UINT nIndex = 0;
	for(nIndex=0; nIndex<=ByteStringExample.Length-1; nIndex++)
	{
		ByteStringExample.Data[nIndex] = (USINT)GetRandomDint(65, 90);
	}
}

void ChangeByteString20()
{
	brsmemset((UDINT)&ByteStringExample20, 0, sizeof(ByteStringExample20));
	ByteStringExample20.nLength = GetRandomDint(1, 20);
	UINT nIndex = 0;
	for(nIndex=0; nIndex<=ByteStringExample20.nLength-1; nIndex++)
	{
		ByteStringExample20.Data[nIndex] = (USINT)GetRandomDint(65, 90);
	}
}

void ChangeDynamicStructArray()
{
	DynamicStructArray.nLength = GetRandomDint(1, 5);
}


