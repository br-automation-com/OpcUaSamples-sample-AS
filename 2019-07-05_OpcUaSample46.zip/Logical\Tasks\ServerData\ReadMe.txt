
Hier werden Variablen zur Verf�gung gestellt, die der eigene OpcUa-Server ver�ffentlicht.

Der Server ist in der System-Konfiguration unter 'OPCUA Server' parametriert. Es ist das PV-Informationsmodell V2.0
eingestellt.

Die User-/Roles-Parametrierung ist unter ConfigurationView/AccessAndSecurity/UserRoleSystem.  Hier ist folgende
Authentifizierung angegeben:
	Username:			Admin
	Password:			admin

Daten sind als globale Variable 'gVarsGlobal' und als lokale Variable 'VarsLocal' angelegt.
Sie wurden in der Datei 'OpcUaMap.uad' (siehe ConfigurationView/Connectivity/OpcUa) f�r den Server konfiguriert.
Sie enthalten die Strukturen 'Read', 'Write' und 'ReadWrite', welche auch so parametriert sind.
Diese wiederum enthalten jeweils ein Unterelement jeden Standard-Datentyps.
Definition siehe LogicalView/Global.typ.
Die Elemente der Unter-Struktur 'Read' werden im Task-Takt (500ms) ge�ndert.

Eine �bersetzung des Attributes 'Description' ist beispielhaft bei den beiden Knoten 'gVarsGlobal' und 'VarsLocal'
implementiert. Dabei werden die Texte aus der Datei 'Texts/OpcUaServerTexts' verwendet.

Ausserdem gibt es die Strukturen 'WriteC' und 'WriteST', auf deren Elemente teilweise von den Clients geschrieben wird.

Einsatz von dynamischen Arrays:
	Auf einer SPS kann ein Array nie dynamisch sein, also keine variable L�nge haben. Die L�nge eines Arrays 
	muss zur Projektierungszeit im AS  festgelegt werden und kann zur Laufzeit nicht mehr ge�ndert werden.
	OpcUa unters�tzt jedoch dynamische Arrays.
	Der B&R-Server kann mit einem Trick ein in der SPS deklariertes Array OpcUa-seitig als dynamisch
	ausliefern. Auch ein empfangenes dynamisches Array kann so auf ein festes SPS-Array �bertragen werden.
	Als einfaches Beispiel soll hier der OpcUa-Datentyp 'ByteString' dienen. Ein ByteString ist einfach ein
	Byte-, also USINT-Array mit variabler L�nge. Dazu gibt es in der Bibliothek 'AsOpcUac' einen Struktur-Typ
	namens 'UAByteString':
		UAByteString : STRUCT							(* Byte string containing length and data	*)
			Length					: DINT;
			Data					: ARRAY[0..MAX_INDEX_BYTESTRING] OF USINT;
		END_STRUCT;
	Das Element 'Data' enth�lt das Array mit fester L�nge, wie auf der SPS ben�tigt.
	Das Element 'Length' enth�lt die Anzahl der g�ltigen Array-Elemente.
	Der am Server ver�ffentlichte Knoten hat automatisch den Datentyp 'ByteString'.
	Im Task wurde eine Instanz 'ByteStringExample' diesen Datentyps definiert, welche im Task-Takt (500ms)
	die L�nge und den Inhalt �ndert.
	Wird nun eine Instanz dieses Datentyps gelesen, so gibt der Server ein Byte-Array mit der unter 'Length'
	angebenen L�nge zur�ck und f�llt es mit den Daten aus 'Data'.
	Wird eine Instanz dieses Datentyps geschrieben, so f�llt der Server die Variablen-Instanz mit den
	entprechenden	Werten. Achtung: Die Anzahl der geschriebenen Elemente darf NICHT die L�nge des Array 'Data'
	�berschreiten, da der Server dann die empfangenen Daten nicht in das Array �bertagen kann. Wird dies
	doch gemacht, f�hrt der Server den Schreibauftrag nicht aus und gibt den Status '0x8074000' = BadTypeMismatch
	zur�ck!
	So ist die maximale Anzahl f�r Length f�r die oben genannte Struktur 'UAByteString' also MAX_INDEX_BYTESTRING
	= 1024. Es k�nnte aber sein, dass dies zu viel oder zu wenig ist. Deswegen ist dieser Trick auch mit 
	benutzerdefinierten Datentypen m�glich. So kann z.B. ein eigener Datentyp mit folgenden Aufbau angelegt werden:
		UAByteString20_TYP : STRUCT
			Length					: DINT;
			Data					: ARRAY[0..19] OF USINT;
		END_STRUCT;
	Eine Instanz-Variable diesen Typs wird genauso behandelt wie oben beschrieben.
	Wichtig dabei ist, dass das erste Element vom Datentyp 'DINT' und das zweite ein Array ist.
	
	Auch der Datentyp des Arrays ist nicht auf USINT begrenzt. So k�nnen auch Struktur-Arrays dynamisch
	gestaltet werden. Im Task ist die Beispiel-Strutur 'OpcUaTestArray_TYP' angelegt:
		OpcUaTestArray_TYP : 	STRUCT 
			nLength : UAArrayLength;
			Data : ARRAY[0..9]OF OpcUaTest_TYP;
		END_STRUCT;
	Auch hier behandelt der Server die Liste dynamisch.
	Hinweis: Der Typ 'UAArrayLength' ist nur eine Ableitung vom Datentyp 'DINT'.
	