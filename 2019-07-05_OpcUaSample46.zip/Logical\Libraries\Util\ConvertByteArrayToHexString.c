
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "Util.h"
#ifdef __cplusplus
	};
#endif

/* Konvertiert ein ByteArray in einen String mit Hex-Zahlen */
unsigned short ConvertByteArrayToHexString(unsigned char* pByteArray, unsigned long nByteArrayLength, plcstring* pHexString, unsigned long nHexStringSize)
{
	UINT nResult = 0;
	brsmemset((UDINT)pHexString, 0, nHexStringSize);
	if(nByteArrayLength > 0)
	{
		UINT nIndex = 0;
		for(nIndex=0; nIndex<=nByteArrayLength-1; nIndex++)
		{
			USINT nValue = *(pByteArray+nIndex);
			STRING sValueHexUsint[16];
			ConvertUsintToHexString(nValue, sValueHexUsint, sizeof(sValueHexUsint));
			brsstrcat((UDINT)pHexString, (UDINT)&sValueHexUsint);
		}
	}
	return nResult;
}
