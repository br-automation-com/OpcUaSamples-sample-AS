
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "Util.h"
#ifdef __cplusplus
	};
#endif

/* Erzeugt einen boolschen Zufallswert */
plcbit GetRandomBool(void)
{
	BOOL bRandom = (BOOL)(GetRandomPercent()*(2));
	return bRandom;
}
